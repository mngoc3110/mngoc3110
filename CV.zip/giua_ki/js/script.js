//typing animation
var typed = new Typed(".typing", {
    strings:["","Student","Teacher","Content Creator", "Marketinger", "Tiktoker", "Youtuber"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})